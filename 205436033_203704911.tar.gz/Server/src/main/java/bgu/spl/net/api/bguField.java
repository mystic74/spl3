package bgu.spl.net.api;

abstract public class bguField {

	protected boolean isDone = false;

	public bguField() {
		super();
	}

	public boolean isDone() {
		return isDone;
	}

}